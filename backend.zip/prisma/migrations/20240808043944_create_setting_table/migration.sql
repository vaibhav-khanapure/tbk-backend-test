-- CreateTable
CREATE TABLE "setting" (
    "id" TEXT NOT NULL,
    "TboTokenId" TEXT NOT NULL,

    CONSTRAINT "setting_pkey" PRIMARY KEY ("id")
);
