-- AlterTable
ALTER TABLE "user" ADD COLUMN     "tbkcredits" INTEGER DEFAULT 0;
