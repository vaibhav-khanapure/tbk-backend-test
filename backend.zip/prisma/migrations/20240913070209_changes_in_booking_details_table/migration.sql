-- AlterTable
ALTER TABLE "bookingDetails" ADD COLUMN     "flightStatus" TEXT;
