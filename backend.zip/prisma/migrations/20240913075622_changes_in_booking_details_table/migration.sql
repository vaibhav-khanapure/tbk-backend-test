-- AlterTable
ALTER TABLE "bookingDetails" ADD COLUMN     "TicketCRInfo" TEXT,
ADD COLUMN     "changeRequestId" TEXT;
