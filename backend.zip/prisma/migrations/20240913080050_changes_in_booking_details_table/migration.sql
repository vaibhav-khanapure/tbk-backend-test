/*
  Warnings:

  - You are about to drop the column `changeRequestId` on the `bookingDetails` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "bookingDetails" DROP COLUMN "changeRequestId";
